from sklearn.linear_model import LogisticRegression
def function():
    MLmodel = LogisticRegression()
    return MLmodel