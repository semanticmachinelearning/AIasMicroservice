import pandas as pd
import numpy as np

def function(path):
    dataset = pd.read_csv(path)
    return dataset